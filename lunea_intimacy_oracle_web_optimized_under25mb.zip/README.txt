LUNEA INTIMACY ORACLE - GitHub/Web optimized assets

- oracle_01.png ~ oracle_36.png: 600x1000 PNG
- oracle_back_new.png: resized proportionally, PNG
- Optimized for mobile web display and GitHub upload.
- Original high-resolution files were not modified.
